* Encoding: UTF-8.
/*********************************************************************************************************/
/*                                                                                                                                 */
/* This SPSS program will extract the United States Sentencing Commission's                  */
/* supplemental file for fiscal year 2017 individual offender file and create a SPSS dataset.  */
/*                                                                                                                                 */
/* Prior to running the program you must update the DAT file location in the                       */
/* FILE HANDLE DATA / NAME line to correspond to the location of the file on your           */
/* computer.                                                                                                                 */
/*                                                                                                                                 */
/* You must also update the file output location in the SAVE OUTFILE statement at the     */
/* end of the program to correspond to the folder you want the output file to be located.       */
/*                                                                                                                                 */
/*********************************************************************************************************/

/* The following line should contain the complete path and name of your raw data file */
/* The last line of this file contains the path to your output '.sav' file */

FILE HANDLE DATA / NAME=".\ussc_sup_fy17.dat" LRECL=83 .

DATA LIST FILE=DATA/
   USSCIDN 1-7              OFFGUIDE 8-10            SENTRNGE 11-13        
   MNTHDEPT 14-30           PCNTDEPT 31-47           SENTTCAP 48-65        
   SENSPCAP 66-83 .      


FORMATS
  MNTHDEPT (F18.15) /      PCNTDEPT (F18.15) /      SENTTCAP (F19.16) /    
  SENSPCAP (F19.16) / .
 
VARIABLE LABELS
   USSCIDN 'USSCIDN'
.

SAVE OUTFILE='.\ussc_sup_fy17.sav'.
