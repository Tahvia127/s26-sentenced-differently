/*****************************************************************************************
*                                                                                        *
* This SAS program will extract the United States Sentencing Commission's supplemental   *
  file for fiscal year 2015 individual offender file and create a SAS dataset.           *
*                                                                                        *
* Prior to running the program you must update the DAT file location in the FILNAME line *
* to correspond to the location of the file on your computer.                            *
*                                                                                        *
* You must also update the library location in the LIBNAME statement to correspond to    *
* the folder you want the output file to be located.                                     *
*                                                                                        *
*****************************************************************************************/

/* The following line should contain the complete path and name of your raw data file */
FILENAME datafile '.\ussc_sup_fy15.dat' ;

/* The following line should contain the directory in which you wish your SAS file to be stored */
libname library '.' ;

/* The following line contains the name (without the extension) for your SAS dataset */
%LET dataset = ussc_sup_fy15 ;

DATA library.&dataset ;
INFILE datafile LRECL=83;
INPUT
   USSCIDN  1-7             OFFGUIDE  8-10           SENTRNGE  11-13       
   MNTHDEPT  14-30          PCNTDEPT  31-47          SENTTCAP  48-65       
   SENSPCAP  66-83        ;                       

LENGTH
   USSCIDN 6                OFFGUIDE 3               SENTRNGE 3 ;

        

RUN ;
